/*  Done by: 	Peh Jun Hao
	Student No.:S8930045B
	Email: 		junhao.peh.2010
*/

public class PASApplication{
	public static void main(String[] args){
	
		ApplicationMenu menu = new ApplicationMenu();
		
		menu.display();
		menu.readOption();
		
	
	}
}